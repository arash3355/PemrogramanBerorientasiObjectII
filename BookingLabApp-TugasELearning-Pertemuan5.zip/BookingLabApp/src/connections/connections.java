/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package connections;

/**
 *
 * @author DELL
 */
import java.sql.Connection;
import java.sql.DriverManager;

public class connections {
    public static Connection connect() {
        try {
            String url = "jdbc:mysql://localhost:3306/pbo_lab";
            String user = "root";
            String pass = "";

            Connection conn = DriverManager.getConnection(url, user, pass);
            System.out.println("Koneksi berhasil!");
            return conn;

        } catch (Exception e) {
            System.out.println("Koneksi gagal: " + e.getMessage());
            return null;
        }
    }
}
