package com.classpbo.latihan1_pbo;

public class Latihan1_PBO {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
